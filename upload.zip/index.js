// server/index.js
require('dotenv').config();
const http = require('http');
const { Server } = require('socket.io');
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 5000;

const path = require('path');

app.use(cors());
app.use(bodyParser.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.static(path.join(__dirname, 'public')));

// Import routes
const authRouter = require('./routes/auth');
const bankRouter = require('./routes/bank');
const investmentRouter = require('./routes/investment');
const adminRouter = require('./routes/admin');
const transactionRouter = require('./routes/transaction');

app.use('/api/auth', authRouter);
app.use('/api/bank', bankRouter);
app.use('/api/investment', investmentRouter);
app.use('/api/admin', adminRouter);
app.use('/api/transaction', transactionRouter);

// Serve React App
app.get('(.*)', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
app.set('io', io);

// Handle socket connections – users join a room named after their userId (passed as query param)
io.on('connection', (socket) => {
  const userId = socket.handshake.query.userId;
  if (userId) {
    socket.join(userId);
    console.log(`Socket connected for user ${userId}`);
  }
  socket.on('disconnect', () => {
    console.log('Socket disconnected');
  });
});

server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
