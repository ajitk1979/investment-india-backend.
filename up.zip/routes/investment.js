// server/routes/investment.js
const express = require('express');
const router = express.Router();
const { readData, writeData } = require('../utils/db');
const multer = require('multer');
const path = require('path');

// Configure multer for persistent receipt storage
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}-${file.originalname}`);
    }
});
const upload = multer({ storage });

// Create investment plan endpoint
router.post('/plan', (req, res) => {
    const { userId, baseAmount, days } = req.body;
    if (!userId || !baseAmount || !days) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    const db = readData();

    // Simple return calculation based on days (demo logic)
    const multiplier = days === 10 ? 1.1 : days === 20 ? 1.3 : days === 30 ? 1.5 : 1;
    const expectedReturn = Math.round(baseAmount * multiplier);

    const investment = {
        userId,
        baseAmount,
        days,
        expectedReturn,
        status: 'pending',
        createdAt: new Date().toISOString()
    };

    db.investments[userId] = investment;
    writeData(db);

    res.json({ message: 'Plan created successfully', investment });
});

// Mock payment endpoint (Now handles receipt upload)
router.post('/payment', upload.single('receipt'), (req, res) => {
    const { userId, paymentMethod } = req.body;
    if (!userId) {
        return res.status(400).json({ error: 'User ID is required' });
    }

    const db = readData();
    const inv = db.investments[userId];

    if (!inv) {
        return res.status(404).json({ error: 'No investment plan found for this user' });
    }

    // Update status to verifying and store receipt path
    inv.status = 'verifying';
    inv.paymentMethod = paymentMethod || 'UPI';
    inv.receiptUrl = req.file ? `/uploads/${req.file.filename}` : null;
    inv.submittedAt = new Date().toISOString();

    writeData(db);

    res.json({ message: 'Receipt submitted for verification', investment: inv });
});

// Get investment status
router.get('/status/:userId', (req, res) => {
    const { userId } = req.params;
    const db = readData();
    const inv = db.investments[userId];
    if (!inv) {
        return res.status(404).json({ error: 'No investment found' });
    }
    res.json({ investment: inv });
});

module.exports = router;
