// server/routes/transaction.js
const express = require('express');
const router = express.Router();
const { readData, writeData, addTransaction } = require('../utils/db');

// Helper to get user balance (simple sum of deposits - withdrawals)
function getUserBalance(userId) {
    const data = readData();
    const userTransactions = (data.transactions || []).filter(t => t.userId === userId);
    let balance = 0;
    userTransactions.forEach(t => {
        if (t.type === 'deposit') balance += Number(t.amount);
        else if (t.type === 'withdraw') balance -= Number(t.amount);
    });
    return balance;
}

// Deposit endpoint
router.post('/deposit', (req, res) => {
    const { userId, amount } = req.body;
    if (!userId || !amount) return res.status(400).json({ error: 'userId and amount required' });
    const transaction = addTransaction(userId, 'deposit', amount);
    // Emit real‑time update to the user
    const io = req.app.get('io');
    if (io) io.to(userId).emit('transaction:update', transaction);
    res.json({ success: true, transaction, balance: getUserBalance(userId) });
});

// Withdraw endpoint (basic balance check)
router.post('/withdraw', (req, res) => {
    const { userId, amount } = req.body;
    if (!userId || !amount) return res.status(400).json({ error: 'userId and amount required' });
    const currentBalance = getUserBalance(userId);
    if (Number(amount) > currentBalance) return res.status(400).json({ error: 'Insufficient balance' });
    const transaction = addTransaction(userId, 'withdraw', amount);
    const io = req.app.get('io');
    if (io) io.to(userId).emit('transaction:update', transaction);
    res.json({ success: true, transaction, balance: getUserBalance(userId) });
});

// History endpoint – returns newest first
router.get('/history/:userId', (req, res) => {
    const { userId } = req.params;
    const data = readData();
    const history = (data.transactions || [])
        .filter(t => t.userId === userId)
        .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    res.json({ success: true, history });
});

module.exports = router;
