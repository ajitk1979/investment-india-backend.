// server/routes/auth.js
const express = require('express');
const router = express.Router();
const { readData, writeData } = require('../utils/db');

// Register endpoint
router.post('/register', (req, res) => {
    const { name, email, mobile } = req.body;
    if (!name || !email || !mobile) {
        return res.status(400).json({ error: 'Name, email, and mobile are required' });
    }

    const db = readData();

    // Check if user already exists
    const user = db.users.find(u => u.mobile === mobile);
    const exists = !!user && user.verified;

    if (!user) {
        db.users.push({ name, email, mobile, verified: false, joinedAt: new Date().toISOString() });
    }

    // Generate mock OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    db.otps[mobile] = otp; // Store OTP mapped to mobile

    writeData(db);

    const otpService = require('../utils/otpService');
    otpService.sendOTP(mobile, otp).catch(err => console.error("OTP Delivery Failed:", err));

    res.json({ message: 'OTP sent successfully', mobile, exists });
});

// Verify OTP endpoint
router.post('/verify-otp', (req, res) => {
    const { mobile, otp } = req.body;
    if (!mobile || !otp) {
        return res.status(400).json({ error: 'Mobile number and OTP are required' });
    }

    const db = readData();
    const storedOtp = db.otps[mobile];

    if (storedOtp && storedOtp === otp) {
        delete db.otps[mobile]; // Clear used OTP

        // Mark user as verified
        const userIndex = db.users.findIndex(u => u.mobile === mobile);
        if (userIndex !== -1) {
            db.users[userIndex].verified = true;
        }

        writeData(db);
        return res.json({ message: 'Verification successful' });
    }

    res.status(401).json({ error: 'Invalid or expired OTP' });
});

module.exports = router;
