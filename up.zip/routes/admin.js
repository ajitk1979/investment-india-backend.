// server/routes/admin.js
const express = require('express');
const router = express.Router();
const { readData, writeData } = require('../utils/db');
const multer = require('multer');
const path = require('path');

// Configure multer for payment QR codes
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, `qr-${Date.now()}-${file.originalname}`);
    }
});
const upload = multer({ storage });

// Get current admin settings
router.get('/settings', (req, res) => {
    const db = readData();
    res.json(db.adminSettings || {});
});

// Update admin settings (UPI/QR)
router.post('/settings', upload.single('qrCode'), (req, res) => {
    const { upiId } = req.body;
    const db = readData();

    db.adminSettings = {
        ...db.adminSettings,
        upiId: upiId || db.adminSettings.upiId,
        qrCode: req.file ? `/uploads/${req.file.filename}` : db.adminSettings.qrCode
    };

    writeData(db);
    res.json({ message: 'Settings updated', settings: db.adminSettings });
});

// Get all user investments for verification
router.get('/investments', (req, res) => {
    const db = readData();
    // Convert investments object to array and join with user names
    const allInvestments = Object.values(db.investments).map(inv => {
        const user = db.users.find(u => u.mobile === inv.userId);
        return { ...inv, userName: user ? user.name : 'Unknown' };
    });
    res.json({ investments: allInvestments });
});

// Verify/Approve investment
router.post('/verify', (req, res) => {
    const { userId, status } = req.body; // status: 'paid' or 'rejected'
    const db = readData();
    if (db.investments[userId]) {
        db.investments[userId].status = status;
        db.investments[userId].verifiedAt = new Date().toISOString();
        writeData(db);
        return res.json({ message: `Investment ${status}`, status });
    }
    res.status(404).json({ error: 'Investment not found' });
});

module.exports = router;
