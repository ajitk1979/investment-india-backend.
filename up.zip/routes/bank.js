// server/routes/bank.js
const express = require('express');
const router = express.Router();
const { readData, writeData } = require('../utils/db');

// Save bank details endpoint
router.post('/details', (req, res) => {
    const { userId, accountNumber, ifsc, amount } = req.body;
    if (!userId || !accountNumber || !ifsc || !amount) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    if (amount < 10000) {
        return res.status(400).json({ error: 'Minimum deposit amount is ₹10,000' });
    }

    const db = readData();
    // In real app, consider encryption
    db.bankDetails[userId] = { accountNumber, ifsc, amount, updatedAt: new Date().toISOString() };
    writeData(db);

    res.json({ message: 'Bank details saved successfully' });
});

// Get bank details (for testing)
router.get('/details/:userId', (req, res) => {
    const { userId } = req.params;
    const db = readData();
    const details = db.bankDetails[userId];

    if (!details) {
        return res.status(404).json({ error: 'No details found' });
    }
    res.json(details);
});

module.exports = router;
